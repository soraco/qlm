﻿using UnityEngine;
using System.Collections;
using QlmLicenseLib;
using System.Diagnostics;
using System.Reflection;
using System.IO;
using System;
using UnityEngine.UI;
using Debug = UnityEngine.Debug;
using System.Runtime.InteropServices;

public class LicenseChecker : MonoBehaviour
{
    public Text statusLabel;
    QLM.LicenseValidator lv = new QLM.LicenseValidator();

    private bool licenseStatus;
    private int exitCode;

    void Start()
    {
        checkLicense();
    }

    void OnApplicationPause(bool pause)
    {
        //App goes to foreground
        if (!pause)
        {
            if (Time.time > 1)
            {
                checkLicense();
            }
        }
    }

    #region C# App Methods

    void checkLicense()
    {
        if (licenseStatus == true)
        {
            return;
        }

        bool needsActivation = false;
        string errorMsg = string.Empty;

        while ((licenseStatus = lv.ValidateLicenseAtStartup(Environment.MachineName, ref needsActivation, ref errorMsg)) == false)
        {
            statusLabel.text = "License status: " + licenseStatus;

            if (!licenseStatus)
            {
                exitCode = DisplayLicenseForm();

                if (exitCode == 4)
                {

#if UNITY_EDITOR
                    UnityEditor.EditorApplication.isPlaying = false;
#else
                    Application.Quit();
#endif
                }
            }
        }

        statusLabel.text = "License status: " + licenseStatus;
    }

    private int DisplayLicenseForm()
    {
#if UNITY_EDITOR
        string auxLocation = @"..\..\Assets\QLM";
#else
        string auxLocation = @"..\..\QLM";
#endif

        Assembly thisAssembly = Assembly.GetExecutingAssembly();
        string location = Path.GetDirectoryName(thisAssembly.Location);

        location = Path.Combine(location, auxLocation);
        location = Path.GetFullPath(location);

        Debug.Log(location);

        string args = "/settings \"";
        args += Path.Combine(location, "Demo 1.0.lw.xml");
        args += "\" ";
  
        return LaunchProcess(Path.Combine(location, "QlmLicenseWizard.exe"), args, true, ProcessWindowStyle.Normal);
    }

    static public int LaunchProcess(string filename, string args, bool bWait, ProcessWindowStyle windowStyle)
    {
        try
        {

            ProcessStartInfo si = new ProcessStartInfo();
            si.FileName = Environment.ExpandEnvironmentVariables(filename);
            si.Arguments = Environment.ExpandEnvironmentVariables(args);
            si.WindowStyle = windowStyle;
            

            si.Verb = "open";
            Process pr = new Process();
            pr.StartInfo = si;
            pr.Start(); // launch process

            if (bWait == true)
            {
                pr.WaitForExit();
                return pr.ExitCode;
            }
        }
        catch (Exception)
        {

        }

        return -1;

    }

    #endregion

    #region Button Events

    public void btnClear_Click()
    {
        try
        {
            // deletes the license keys stored on the end user system.
            lv.DeleteKeys();


        }
        catch (Exception ex)
        {
        }
    }

    public void btnLicense_Click()
    {
        DisplayLicenseForm();
    }

    public void btnExit_Click()
    {
#if !UNITY_EDITOR
        Application.Quit();
#endif

#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
    }

#endregion
}
