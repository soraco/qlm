﻿using UnityEngine;
using UnityEditor;
using UnityEditor.Callbacks;
using System.Diagnostics;
using Debug = UnityEngine.Debug;

public class PostProcessBuild
{
    const string directory = "Assets/QLM";

    [PostProcessBuildAttribute(1)]
    public static void OnPostprocessBuild(BuildTarget target, string pathToBuiltProject)
    {
        Debug.Log(pathToBuiltProject);

        int index = pathToBuiltProject.LastIndexOf("/");

        if (index > 0)
        {
            string path = pathToBuiltProject.Substring(0, index + 1);
            FileUtil.CopyFileOrDirectory(directory, path + "QLM");
        }
    }
}