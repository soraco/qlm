﻿QLMIMPORT
---------

QlmImport allows you to import data from a comma separated file (CSV) into the QLM database. You must have a license server already setup.

QlmImport can import customers and orders.

USAGE
-----

- Compile and Build the application
- To import customers, create a customers.csv file as outlined in the CUSTOMERS section below. A sample customers.csv is included in the Visual Studio project.
- To import orders, create an orders.csv file as outlined in the ORDERS section below. A sample orders.csv is included in the Visual Studio project.
- It is recommended to import customers before you import orders
- Before you import data, go to the "License Server Settings" tab and point the tool to your own server by setting the URL, the CommunicationEncryptionKey and the AdminEncryptionKey
- Once you have configured the "License Server Settings" , select the file to import and click Import.

PLEASE MAKE SURE YOU READ THE "IMPORTANT" NOTES BELOW. They will save you hours of troubleshooting.

The CSVParser project was downloaded from codeproject.com :  https://www.codeproject.com/Articles/1128472/CSV-File-Parser

We provide the source code so that you can modify this at will. This tool is not officially supported.

If you improve this import tool by fixing bugs or adding features, we'd love to get your improvements so that we can share them with our users. 
Email us your updates to: support@soraco.co

CUSTOMERS
---------

To import customers, create a CSV file that contains a comma separated list of customers as follows:

1. The first row of the CSV file must contain a comma separated list of column names. The supported column names are:

	name,email,company,phone,address1,address2,fax,mobile,city,state,zip,country,notes,affiliateID

	IMPORTANT: email is mandatory.

2. Each subsequent row must contain values associated to the columns defined in the first row.
  

3. IMPORTANT: 		
	- No spaces are allowed before or after the commas, be it in the first row or subsequent rows.
		This will work: col1,col2,col3
		This will fail: col1, col2, col3

	- Empty double quotes "" are not allowed. To skip a field, just skip it like this: "val1",,"val3" and not like this: "val1","","val3"


ORDERS
------

To import orders, create a CSV file that contains a comma separated list of customers as follows:

1. The first row of the CSV file must contain a comma separated list of column names. The supported column names are:

	ProductID,Major,Minor,email,numLicenses,userData,affiliateID,expiryDate,expiryDuration,orderID,maintenancePlanExpiryDate

	IMPORTANT: ProductID,Major,Minor are mandatory.

2. Each subsequent row must contain values associated to the columns defined in the first row.

3. IMPORTANT: 
	- No spaces are allowed before or after the commas, be it in the first row or subsequent rows.
		This will work: col1,col2,col3
		This will fail: col1, col2, col3

	- Empty double quotes "" are not allowed. To skip a value, just skip it like this: "val1",,"val3" and not like this: "val1","","val3"

	




