﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CSVParser
{
	/// <summary>
	/// Provides some essential extension methods for the string class.
	/// </summary>
	public static class ExtendStrings
	{
		//FULL DISCLOSURE - I found this method on StackOverflow, but I neglected to make 
		// note of the person that posted it. I only changed it to match my formatting style.
		/// <summary>
		/// Determines whether this string is "like" the specified string. Performs a SQL "LIKE" 
		/// comparison. 
		/// </summary>
		/// <param name="str">This string.</param>
		/// <param name="like">The string to compare it against.</param>
		/// <returns>True if the string is like the specified pattern</returns>
		/// <remarks>Full disclosure - I got this method off StackOverflow, but I do not recall the 
		/// name of the guy that posted it in response to a question.</remarks>
		public static bool IsLike(this string str, string pattern)
		{
			// This code is much faster than a regular expression that performs the 
			// same comparison.
			bool isMatch          = true;
			bool isWildCardOn     = false;
			bool isCharWildCardOn = false;
			bool isCharSetOn      = false;
			bool isNotCharSetOn   = false;
			bool endOfPattern     = false;
			int  lastWildCard     = -1;
			int  patternIndex     = 0;
			char p                = '\0';
			List<char> set        = new List<char>();

			for (int i = 0; i < str.Length; i++)
			{
				char c = str[i];
				endOfPattern = (patternIndex >= pattern.Length);
				if (!endOfPattern)
				{
					p = pattern[patternIndex];
					if (!isWildCardOn && p == '%')
					{
						lastWildCard = patternIndex;
						isWildCardOn = true;
						while (patternIndex < pattern.Length && pattern[patternIndex] == '%')
						{
							patternIndex++;
						}
						p = (patternIndex >= pattern.Length)  ? '\0' : p = pattern[patternIndex];
					}
					else if (p == '_')
					{
						isCharWildCardOn = true;
						patternIndex++;
					}
					else if (p == '[')
					{
						if (pattern[++patternIndex] == '^')
						{
							isNotCharSetOn = true;
							patternIndex++;
						}
						else 
						{
							isCharSetOn = true;
						}

						set.Clear();
						if (pattern[patternIndex + 1] == '-' && pattern[patternIndex + 3] == ']')
						{
							char start    = char.ToUpper(pattern[patternIndex]);
							patternIndex += 2;
							char end      = char.ToUpper(pattern[patternIndex]);
							if (start <= end)
							{
								for (char ci = start; ci <= end; ci++)
								{
									set.Add(ci);
								}
							}
							patternIndex++;
						}

						while (patternIndex < pattern.Length && pattern[patternIndex] != ']')
						{
							set.Add(pattern[patternIndex]);
							patternIndex++;
						}
						patternIndex++;
					}
				}

				if (isWildCardOn)
				{
					if (char.ToUpper(c) == char.ToUpper(p))
					{
						isWildCardOn = false;
						patternIndex++;
					}
				}
				else if (isCharWildCardOn)
				{
					isCharWildCardOn = false;
				}
				else if (isCharSetOn || isNotCharSetOn)
				{
					bool charMatch = (set.Contains(char.ToUpper(c)));
					if ((isNotCharSetOn && charMatch) || (isCharSetOn && !charMatch))
					{
						if (lastWildCard >= 0) 
						{
							patternIndex = lastWildCard;
						}
						else
						{
							isMatch = false;
							break;
						}
					}
					isNotCharSetOn = isCharSetOn = false;
				}
				else
				{
					if (char.ToUpper(c) == char.ToUpper(p))
					{
						patternIndex++;
					}
					else
					{
						if (lastWildCard >= 0) 
						{
							patternIndex = lastWildCard;
						}
						else
						{
							isMatch = false;
							break;
						}
					}
				}
			}
			endOfPattern = (patternIndex >= pattern.Length);

			if (isMatch && !endOfPattern)
			{
				bool isOnlyWildCards = true;
				for (int i = patternIndex; i < pattern.Length; i++)
				{
					if (pattern[i] != '%')
					{
						isOnlyWildCards = false;
						break;
					}
				}
				if (isOnlyWildCards) 
				{
					endOfPattern = true;
				}
			}
			return (isMatch && endOfPattern);
		}

		/// <summary>
		/// Reverses the string
		/// </summary>
		/// <param name="text">The string to be reversed</param>
		/// <returns>The reversed string</returns>
		public static string ReverseText(this string text)
		{
			if (!string.IsNullOrEmpty(text))
			{
				int pivotPos = text.Length / 2;
				for (int i = 0; i < pivotPos; i++)
				{
					text = text.Insert(text.Length - i, text.Substring(i, 1)).Remove(i, 1);
					text = text.Insert(i, text.Substring(text.Length - (i + 2), 1)).Remove(text.Length - (i + 1), 1);
				}
			}
			return text;
		}

		/// <summary>
		/// Determines whether the string is a substring of the specified container
		/// </summary>
		/// <param name="str">The string to be checked</param>
		/// <param name="container">A comma-delimited string containing interesting values</param>
		/// <returns>True if the string is in the container</returns>
		public static bool IsInExact(this string str, string container)
		{
			// split the container into its component parts
			string[] parts = container.Split(',');
			// look for a match
			var result = parts.Where(x=>x == str).FirstOrDefault();
			// return the results
			return (result != null);
		}

		public static bool StartsWithSingleDoubleQuote(this string text)
		{
			bool result = false;
			switch(text.Length)
			{
				case 0 : result = false; break;
				case 1 : 
				case 2 : 
				case 3 : result = (text[0] == '"'); break;
				default: result = (text.StartsWith("\"") && text[1] != '"'); break;
			}
			return result;
		}

		public static bool EndsWithSingleDoubleQuote(this string text)
		{
			bool result = false;
			switch(text.Length)
			{
				case 0 : 
				case 1 : 
				case 2 : 
				case 3 : result = false; break;
				default: result = (text.EndsWith("\"") && text[text.Length-2] != '"'); break;
			}
			return result;
		}
		public static bool EscapedWithQuotes(this string text)
		{
			bool result = (text.StartsWithSingleDoubleQuote() && text.EndsWithSingleDoubleQuote());
			return result;
		}

		public static bool IsProbablyString(this string text)
		{
			text = text.Trim().Replace("$", "").Replace(",","");
			int i;
			double d;
			DateTime date;
			bool result = (!string.IsNullOrEmpty(text) && !int.TryParse(text, out i) && !double.TryParse(text, out d) && !DateTime.TryParse(text, out date));
			return result;
		}

		public static bool IsQuotedString(this string text)
		{
			return (text.StartsWithSingleDoubleQuote() && text.EndsWithSingleDoubleQuote());
		}

		public static int LastAvailableSlot(this List<string> list)
		{
			int index = -1;
			int count = list.Where(x=>x == null || x == string.Empty).Count();
			if (count > 0)
			{
				for (int i = list.Count - 1; i>= 0; i--)
				{
					if (string.IsNullOrEmpty(list[i]))
					{
						index = i;
						break;
					}
				}
			}
			return index;
		}

		public static int FirstAvailableSlot(this List<string> list)
		{
			int index = -1;
			int count = list.Where(x=>x == null || x == string.Empty).Count();
			if (count > 0)
			{
				for (int i = 0; i < list.Count; i++)
				{
					if (string.IsNullOrEmpty(list[i]))
					{
						index = i;
						break;
					}
				}
			}
			return index;
		}
	
		public static int AvailableSlots(this List<string> list)
		{
			int count = list.Where(x=>x == null || x == string.Empty).Count();
			return count;
		}

		public static string CommaSeparated(this List<string> list)
		{
			string result = string.Empty;
			foreach(string item in list)
			{
				result = (result.Length == 0) ? item : string.Concat(result, ",", item);
			}
			return result;
		}

	}

}
