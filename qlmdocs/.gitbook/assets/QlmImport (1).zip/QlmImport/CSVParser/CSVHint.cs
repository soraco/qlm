﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVParser
{
	public enum CSVHintType { Int, Double, DateTime, String, QuotedString };

	// Use a list of this class to help parsing.
	public class CSVHint
	{
		public int         ColumnIndex { get; set; }
		public string      ColumnName  { get; set; }
		public CSVHintType DataType    { get; set; }
	}

}
