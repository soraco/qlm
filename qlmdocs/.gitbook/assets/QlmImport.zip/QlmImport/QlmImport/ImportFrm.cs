﻿using CSVParser;
using QlmImport.Properties;
using QlmLicenseLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QlmImport
{
    public partial class ImportFrm : Form
    {
        QlmLicense license;

        public ImportFrm()
        {
            InitializeComponent();

            license = new QlmLicense();
            

        }

        private void InitalizeLicense ()
        {
            license.DefaultWebServiceUrl = txtUrl.Text;
            license.CommunicationEncryptionKey = txtCommunicationEncryptionKey.Text;
            license.AdminEncryptionKey = txtAdminEncryptionKey.Text;
        }

        private void btnImportCustomers_Click(object sender, EventArgs e)
        {
            try
            {
                InitalizeLicense();

                txtResultCustomers.Text = string.Empty;

                QlmCustomerParser parser = new QlmCustomerParser(license);
                parser.ExactDateTimeFormat = "yyyy-MM-dd";
                parser.Parse(txtCustomersFile.Text);

                StringBuilder sbResult = parser.SbResult;
                sbResult.Insert(0, String.Format("Successfully imported {0} records.\r\n", parser.ImportCount));

                txtResultCustomers.Text = sbResult.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "QLM Import", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnImportOrders_Click(object sender, EventArgs e)
        {
            try
            {
                InitalizeLicense();

                txtResultOrders.Text = string.Empty;

                QlmOrderParser parser = new QlmOrderParser(license);
                parser.ExactDateTimeFormat = "yyyy-MM-dd";

                parser.Parse(txtOrdersFile.Text);

                StringBuilder sbResult = parser.SbResult;
                sbResult.Insert(0, String.Format("Successfully imported {0} records.\r\n", parser.ImportCount));

                txtResultOrders.Text = sbResult.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "QLM Import", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBrowseCustomers_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = txtCustomersFile.Text;

            openFileDialog1.Filter = "CSV File (*.csv)|*.csv|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtCustomersFile.Text = openFileDialog1.FileName;

                Settings.Default.customersFile = txtCustomersFile.Text;
                Settings.Default.Save();
            }
        }

        private void btnBrowseOrders_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = txtOrdersFile.Text;

            openFileDialog1.Filter = "CSV File (*.csv)|*.csv|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtOrdersFile.Text = openFileDialog1.FileName;

                Settings.Default.ordersFile = txtOrdersFile.Text;
                Settings.Default.Save();
            }
        }

        private void ImportFrm_Load(object sender, EventArgs e)
        {
            txtCustomersFile.Text = Settings.Default.customersFile;
            txtOrdersFile.Text = Settings.Default.ordersFile;

            txtUrl.Text = Settings.Default.licenseServerUrl;
            txtCommunicationEncryptionKey.Text = Settings.Default.communcationEncryptionKey;
            txtAdminEncryptionKey.Text = Settings.Default.adminEncryptionKey;
        }

        private void txtUrl_TextChanged(object sender, EventArgs e)
        {
            Settings.Default.licenseServerUrl = txtUrl.Text;
            Settings.Default.Save();

        }

        private void txtCommunicationEncryptionKey_TextChanged(object sender, EventArgs e)
        {
            Settings.Default.communcationEncryptionKey = txtCommunicationEncryptionKey.Text;
            Settings.Default.Save();
        }

        private void txtAdminEncryptionKey_TextChanged(object sender, EventArgs e)
        {
            Settings.Default.adminEncryptionKey = txtAdminEncryptionKey.Text;
            Settings.Default.Save();
        }

        private void btnImportUsergroups_Click(object sender, EventArgs e)
        {
            InitalizeLicense();

            txtResultUserGroups.Text = string.Empty;

            QlmUserGroupsParser parser = new QlmUserGroupsParser(license);

            txtResultUserGroups.Text = parser.Parse(txtUserGroupsFile.Text);
        }
    }
}
