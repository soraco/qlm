﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSVParser;
using QlmLicenseLib;

namespace QlmImport
{


    // Usage: 
    //		CSVFileParser parser = new CSVFileParser();
    //		parser.Parse(@"pathto\myfile.csv");
    // (accepts either stream or filename)

    public class QlmCustomerParser : CSVParser.CSVParser
    {
        QlmLicense license1 = null;

        public QlmCustomerParser(QlmLicense license) : base()
        {
#if __Z__
			this.Hints.Add(new CSVHint(){ ColumnIndex=0, ColumnName = "Col1", DataType=CSVHintType.Int });
			this.Hints.Add(new CSVHint(){ ColumnIndex=1, ColumnName = "Col2", DataType=CSVHintType.String });
			this.Hints.Add(new CSVHint(){ ColumnIndex=2, ColumnName = "Col3", DataType=CSVHintType.QuotedString });
			this.Hints.Add(new CSVHint(){ ColumnIndex=3, ColumnName = "Col4", DataType=CSVHintType.String });
			this.Hints.Add(new CSVHint(){ ColumnIndex=4, ColumnName = "Col5", DataType=CSVHintType.QuotedString });
			this.Hints.Add(new CSVHint(){ ColumnIndex=5, ColumnName = "Col6", DataType=CSVHintType.QuotedString });
#endif
            license1 = license;

        }

        /// <summary>
        /// Parses the CurrentData property. The CurrentData property contains the parsed 
        /// comma-delimited line from the stream/file, and this method is called after each line is 
        /// parsed.
        /// </summary>
        protected override void ProcessFields(bool isMalformed)
        {
            if (this.CurrentData != null && !isMalformed)
            {
                string customerEmail = string.Empty;

                // TO-DO: Your stuff
                try
                {
                    customerEmail = this.FindValue("email", "");

                    string customerName = this.FindValue("name", "");
                    
                    string customerCompany = this.FindValue("company", "");
                    string customerPhone = this.FindValue("phone", "");
                    string customerAddress1 = this.FindValue("address1", "");
                    string customerAddress2 = this.FindValue("address2", "");

                    string customerFax = this.FindValue("fax", "");
                    string customerMobile = this.FindValue("mobile", "");
                    string customerCity = this.FindValue("city", "");
                    string customerState = this.FindValue("state", "");
                    string customerZip = this.FindValue("zip", "");
                    string customerCountry = this.FindValue("country", "");
                    string customerNotes = this.FindValue("notes", "");
                    string affiliateID = this.FindValue("affiliateID", "");

                    string response = string.Empty;



                    license1.AddUserEx(string.Empty, customerName, customerEmail, customerPhone, customerFax, customerMobile, customerCompany, 
                                        customerAddress1, customerAddress2, customerCity, customerState, customerZip, customerCountry, 
                                        string.Empty, customerNotes, true, affiliateID, true, out response);

                    ILicenseInfo li = new LicenseInfo();
                    string message = string.Empty;

                    if (license1.ParseResults (response, ref li, ref message))
                    {
                        // all good
                        ImportCount++;
                    }
                    else
                    {
                        // error adding the user
                        SbResult.AppendFormat("Error adding customer {0}. Error: {1}\r\n", customerEmail, message);
                    }
                    
                }
                catch (FindValueException fvex)
                {
                    // this just gets rid of the compiler "declared but never used" warning.
                    if (fvex != null) { }

                    //TO-DO: react to an exception thrown because the value found could not be cast 
                    // to the expected type.
                    SbResult.AppendFormat("Error adding customer {0}. Error: {1}\r\n", customerEmail, fvex.Message);

                }
            }
            else
            {
                SbResult.Append("The data is malformed.\r\n");
            }
        }

        protected override void Finished()
        {
            //TO-DO:	Celebration that could include dancing naked around a fire, singing songs 
            //			of a successful parsing event.

            // At this point you can examine the properties that show valid, invalid, and corrected 
            // line counts, as well as total lines processed (excluding the header row and blank 
            // lines).

        }

    }
}

