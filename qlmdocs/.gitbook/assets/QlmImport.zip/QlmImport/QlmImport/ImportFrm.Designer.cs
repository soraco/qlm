﻿namespace QlmImport
{
    partial class ImportFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ImportFrm));
            this.btnImportCustomers = new System.Windows.Forms.Button();
            this.txtCustomersFile = new System.Windows.Forms.TextBox();
            this.btnImportOrders = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtOrdersFile = new System.Windows.Forms.TextBox();
            this.btnBrowseCustomers = new System.Windows.Forms.Button();
            this.btnBrowseOrders = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageCustomers = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.txtResultCustomers = new System.Windows.Forms.TextBox();
            this.tabPageOrders = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.txtResultOrders = new System.Windows.Forms.TextBox();
            this.tabPageSettings = new System.Windows.Forms.TabPage();
            this.txtAdminEncryptionKey = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCommunicationEncryptionKey = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtUrl = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tabPageUserGroups = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.txtResultUserGroups = new System.Windows.Forms.TextBox();
            this.btnBrowseUserGroupsFile = new System.Windows.Forms.Button();
            this.txtUserGroupsFile = new System.Windows.Forms.TextBox();
            this.btnImportUsergroups = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPageCustomers.SuspendLayout();
            this.tabPageOrders.SuspendLayout();
            this.tabPageSettings.SuspendLayout();
            this.tabPageUserGroups.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnImportCustomers
            // 
            this.btnImportCustomers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImportCustomers.Location = new System.Drawing.Point(529, 41);
            this.btnImportCustomers.Name = "btnImportCustomers";
            this.btnImportCustomers.Size = new System.Drawing.Size(72, 23);
            this.btnImportCustomers.TabIndex = 0;
            this.btnImportCustomers.Text = "&Import ";
            this.btnImportCustomers.UseVisualStyleBackColor = true;
            this.btnImportCustomers.Click += new System.EventHandler(this.btnImportCustomers_Click);
            // 
            // txtCustomersFile
            // 
            this.txtCustomersFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomersFile.Location = new System.Drawing.Point(9, 41);
            this.txtCustomersFile.Name = "txtCustomersFile";
            this.txtCustomersFile.Size = new System.Drawing.Size(480, 21);
            this.txtCustomersFile.TabIndex = 1;
            // 
            // btnImportOrders
            // 
            this.btnImportOrders.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImportOrders.Location = new System.Drawing.Point(529, 43);
            this.btnImportOrders.Name = "btnImportOrders";
            this.btnImportOrders.Size = new System.Drawing.Size(72, 23);
            this.btnImportOrders.TabIndex = 2;
            this.btnImportOrders.Text = "Import";
            this.btnImportOrders.UseVisualStyleBackColor = true;
            this.btnImportOrders.Click += new System.EventHandler(this.btnImportOrders_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(400, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "Select a file that contains a comma separated list  of customers to import";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(378, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "Select a file that contains a comma separated list  of orders to import";
            // 
            // txtOrdersFile
            // 
            this.txtOrdersFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrdersFile.Location = new System.Drawing.Point(9, 43);
            this.txtOrdersFile.Name = "txtOrdersFile";
            this.txtOrdersFile.Size = new System.Drawing.Size(480, 21);
            this.txtOrdersFile.TabIndex = 5;
            // 
            // btnBrowseCustomers
            // 
            this.btnBrowseCustomers.Location = new System.Drawing.Point(495, 41);
            this.btnBrowseCustomers.Name = "btnBrowseCustomers";
            this.btnBrowseCustomers.Size = new System.Drawing.Size(28, 23);
            this.btnBrowseCustomers.TabIndex = 8;
            this.btnBrowseCustomers.Text = "...";
            this.btnBrowseCustomers.UseVisualStyleBackColor = true;
            this.btnBrowseCustomers.Click += new System.EventHandler(this.btnBrowseCustomers_Click);
            // 
            // btnBrowseOrders
            // 
            this.btnBrowseOrders.Location = new System.Drawing.Point(495, 43);
            this.btnBrowseOrders.Name = "btnBrowseOrders";
            this.btnBrowseOrders.Size = new System.Drawing.Size(28, 23);
            this.btnBrowseOrders.TabIndex = 9;
            this.btnBrowseOrders.Text = "...";
            this.btnBrowseOrders.UseVisualStyleBackColor = true;
            this.btnBrowseOrders.Click += new System.EventHandler(this.btnBrowseOrders_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPageCustomers);
            this.tabControl1.Controls.Add(this.tabPageOrders);
            this.tabControl1.Controls.Add(this.tabPageUserGroups);
            this.tabControl1.Controls.Add(this.tabPageSettings);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(623, 327);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPageCustomers
            // 
            this.tabPageCustomers.Controls.Add(this.label1);
            this.tabPageCustomers.Controls.Add(this.txtResultCustomers);
            this.tabPageCustomers.Controls.Add(this.btnBrowseCustomers);
            this.tabPageCustomers.Controls.Add(this.txtCustomersFile);
            this.tabPageCustomers.Controls.Add(this.btnImportCustomers);
            this.tabPageCustomers.Controls.Add(this.label2);
            this.tabPageCustomers.Location = new System.Drawing.Point(4, 22);
            this.tabPageCustomers.Name = "tabPageCustomers";
            this.tabPageCustomers.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageCustomers.Size = new System.Drawing.Size(615, 301);
            this.tabPageCustomers.TabIndex = 0;
            this.tabPageCustomers.Text = "Import Customers";
            this.tabPageCustomers.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "Result";
            // 
            // txtResultCustomers
            // 
            this.txtResultCustomers.Location = new System.Drawing.Point(9, 87);
            this.txtResultCustomers.Multiline = true;
            this.txtResultCustomers.Name = "txtResultCustomers";
            this.txtResultCustomers.Size = new System.Drawing.Size(480, 208);
            this.txtResultCustomers.TabIndex = 9;
            // 
            // tabPageOrders
            // 
            this.tabPageOrders.Controls.Add(this.label4);
            this.tabPageOrders.Controls.Add(this.txtResultOrders);
            this.tabPageOrders.Controls.Add(this.btnBrowseOrders);
            this.tabPageOrders.Controls.Add(this.txtOrdersFile);
            this.tabPageOrders.Controls.Add(this.label3);
            this.tabPageOrders.Controls.Add(this.btnImportOrders);
            this.tabPageOrders.Location = new System.Drawing.Point(4, 22);
            this.tabPageOrders.Name = "tabPageOrders";
            this.tabPageOrders.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageOrders.Size = new System.Drawing.Size(615, 301);
            this.tabPageOrders.TabIndex = 1;
            this.tabPageOrders.Text = "Import Orders";
            this.tabPageOrders.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 15);
            this.label4.TabIndex = 12;
            this.label4.Text = "Result";
            // 
            // txtResultOrders
            // 
            this.txtResultOrders.Location = new System.Drawing.Point(9, 87);
            this.txtResultOrders.Multiline = true;
            this.txtResultOrders.Name = "txtResultOrders";
            this.txtResultOrders.Size = new System.Drawing.Size(480, 208);
            this.txtResultOrders.TabIndex = 11;
            // 
            // tabPageSettings
            // 
            this.tabPageSettings.Controls.Add(this.txtAdminEncryptionKey);
            this.tabPageSettings.Controls.Add(this.label7);
            this.tabPageSettings.Controls.Add(this.txtCommunicationEncryptionKey);
            this.tabPageSettings.Controls.Add(this.label6);
            this.tabPageSettings.Controls.Add(this.txtUrl);
            this.tabPageSettings.Controls.Add(this.label5);
            this.tabPageSettings.Location = new System.Drawing.Point(4, 22);
            this.tabPageSettings.Name = "tabPageSettings";
            this.tabPageSettings.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSettings.Size = new System.Drawing.Size(615, 301);
            this.tabPageSettings.TabIndex = 2;
            this.tabPageSettings.Text = "License Server Settings";
            this.tabPageSettings.UseVisualStyleBackColor = true;
            // 
            // txtAdminEncryptionKey
            // 
            this.txtAdminEncryptionKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdminEncryptionKey.Location = new System.Drawing.Point(9, 167);
            this.txtAdminEncryptionKey.Name = "txtAdminEncryptionKey";
            this.txtAdminEncryptionKey.Size = new System.Drawing.Size(583, 21);
            this.txtAdminEncryptionKey.TabIndex = 9;
            this.txtAdminEncryptionKey.TextChanged += new System.EventHandler(this.txtAdminEncryptionKey_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(125, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "Admin Encryption Key";
            // 
            // txtCommunicationEncryptionKey
            // 
            this.txtCommunicationEncryptionKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCommunicationEncryptionKey.Location = new System.Drawing.Point(9, 105);
            this.txtCommunicationEncryptionKey.Name = "txtCommunicationEncryptionKey";
            this.txtCommunicationEncryptionKey.Size = new System.Drawing.Size(583, 21);
            this.txtCommunicationEncryptionKey.TabIndex = 7;
            this.txtCommunicationEncryptionKey.TextChanged += new System.EventHandler(this.txtCommunicationEncryptionKey_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 83);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(177, 15);
            this.label6.TabIndex = 8;
            this.label6.Text = "Communication Encryption Key";
            // 
            // txtUrl
            // 
            this.txtUrl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUrl.Location = new System.Drawing.Point(9, 48);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(583, 21);
            this.txtUrl.TabIndex = 5;
            this.txtUrl.TextChanged += new System.EventHandler(this.txtUrl_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(159, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "URL to QLM License Server";
            // 
            // tabPageUserGroups
            // 
            this.tabPageUserGroups.Controls.Add(this.label8);
            this.tabPageUserGroups.Controls.Add(this.txtResultUserGroups);
            this.tabPageUserGroups.Controls.Add(this.btnBrowseUserGroupsFile);
            this.tabPageUserGroups.Controls.Add(this.txtUserGroupsFile);
            this.tabPageUserGroups.Controls.Add(this.btnImportUsergroups);
            this.tabPageUserGroups.Controls.Add(this.label9);
            this.tabPageUserGroups.Location = new System.Drawing.Point(4, 22);
            this.tabPageUserGroups.Name = "tabPageUserGroups";
            this.tabPageUserGroups.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageUserGroups.Size = new System.Drawing.Size(615, 301);
            this.tabPageUserGroups.TabIndex = 3;
            this.tabPageUserGroups.Text = "User Groups";
            this.tabPageUserGroups.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(10, 62);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 15);
            this.label8.TabIndex = 16;
            this.label8.Text = "Result";
            // 
            // txtResultUserGroups
            // 
            this.txtResultUserGroups.Location = new System.Drawing.Point(13, 80);
            this.txtResultUserGroups.Multiline = true;
            this.txtResultUserGroups.Name = "txtResultUserGroups";
            this.txtResultUserGroups.Size = new System.Drawing.Size(480, 208);
            this.txtResultUserGroups.TabIndex = 15;
            // 
            // btnBrowseUserGroupsFile
            // 
            this.btnBrowseUserGroupsFile.Location = new System.Drawing.Point(499, 34);
            this.btnBrowseUserGroupsFile.Name = "btnBrowseUserGroupsFile";
            this.btnBrowseUserGroupsFile.Size = new System.Drawing.Size(28, 23);
            this.btnBrowseUserGroupsFile.TabIndex = 14;
            this.btnBrowseUserGroupsFile.Text = "...";
            this.btnBrowseUserGroupsFile.UseVisualStyleBackColor = true;
            // 
            // txtUserGroupsFile
            // 
            this.txtUserGroupsFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUserGroupsFile.Location = new System.Drawing.Point(13, 34);
            this.txtUserGroupsFile.Name = "txtUserGroupsFile";
            this.txtUserGroupsFile.Size = new System.Drawing.Size(480, 21);
            this.txtUserGroupsFile.TabIndex = 12;
            // 
            // btnImportUsergroups
            // 
            this.btnImportUsergroups.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnImportUsergroups.Location = new System.Drawing.Point(533, 34);
            this.btnImportUsergroups.Name = "btnImportUsergroups";
            this.btnImportUsergroups.Size = new System.Drawing.Size(72, 23);
            this.btnImportUsergroups.TabIndex = 11;
            this.btnImportUsergroups.Text = "&Import ";
            this.btnImportUsergroups.UseVisualStyleBackColor = true;
            this.btnImportUsergroups.Click += new System.EventHandler(this.btnImportUsergroups_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(10, 12);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(415, 15);
            this.label9.TabIndex = 13;
            this.label9.Text = "Select a file that contains a comma separated list  of User Groups  to import";
            // 
            // ImportFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(647, 346);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ImportFrm";
            this.Text = "Quick License Manager - Import Data";
            this.Load += new System.EventHandler(this.ImportFrm_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPageCustomers.ResumeLayout(false);
            this.tabPageCustomers.PerformLayout();
            this.tabPageOrders.ResumeLayout(false);
            this.tabPageOrders.PerformLayout();
            this.tabPageSettings.ResumeLayout(false);
            this.tabPageSettings.PerformLayout();
            this.tabPageUserGroups.ResumeLayout(false);
            this.tabPageUserGroups.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnImportCustomers;
        private System.Windows.Forms.TextBox txtCustomersFile;
        private System.Windows.Forms.Button btnImportOrders;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtOrdersFile;
        private System.Windows.Forms.Button btnBrowseCustomers;
        private System.Windows.Forms.Button btnBrowseOrders;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageCustomers;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtResultCustomers;
        private System.Windows.Forms.TabPage tabPageOrders;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtResultOrders;
        private System.Windows.Forms.TabPage tabPageSettings;
        private System.Windows.Forms.TextBox txtAdminEncryptionKey;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCommunicationEncryptionKey;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtUrl;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabPageUserGroups;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtResultUserGroups;
        private System.Windows.Forms.Button btnBrowseUserGroupsFile;
        private System.Windows.Forms.TextBox txtUserGroupsFile;
        private System.Windows.Forms.Button btnImportUsergroups;
        private System.Windows.Forms.Label label9;
    }
}

