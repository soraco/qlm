﻿//#define __FROM_FILE__

using System.IO;

namespace CSVParser
{
	class Program
	{
		static void Main(string[] args)
		{
            // If you want to test it with a stream instead of a file, comment out the compiler 
            // directive at the top of this file.

//            CSVFileParser parser = new CSVFileParser();
//#if __FROM_FILE__
//			parser.Parse("sample1.csv");
//#else
//			using (System.IO.FileStream stream = new System.IO.FileStream("sample2.csv", FileMode.Open, FileAccess.Read))
//			{
//				parser.Parse(stream);
//			}
//#endif

		}
	}
}
