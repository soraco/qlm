﻿using System;
using System.Runtime.Serialization;

namespace CSVParser
{
	public class MalformedLineException : Exception, ISerializable
	{
		public string CurrentData { get; set; }

		public MalformedLineException()
		{
		}
		public MalformedLineException(string message) : base(message)
		{
		}
		public MalformedLineException(string message, Exception inner) : base (message, inner)
		{
		}

		public MalformedLineException(string currentData, string message) : base(message)
		{
			this.CurrentData = currentData;
		}
		public MalformedLineException(string currentData, string message, Exception inner) : base (message, inner)
		{
			this.CurrentData = currentData;
		}
	}

	public class ColumnCountException : Exception, ISerializable
	{
		public string CurrentData { get; set; }

		public ColumnCountException()
		{
		}
		public ColumnCountException(string message) : base(message)
		{
		}
		public ColumnCountException(string message, Exception inner) : base (message, inner)
		{
		}

		public ColumnCountException(string currentData, string message) : base(message)
		{
			this.CurrentData = currentData;
		}
		public ColumnCountException(string currentData, string message, Exception inner) : base (message, inner)
		{
			this.CurrentData = currentData;
		}
	}

	public class FindValueException : Exception, ISerializable
	{
		public string CurrentData { get; set; }

		public FindValueException()
		{
		}
		public FindValueException(string message) : base(message)
		{
		}
		public FindValueException(string message, Exception inner) : base (message, inner)
		{
		}

		public FindValueException(string currentData, string message) : base(message)
		{
			this.CurrentData = currentData;
		}
		public FindValueException(string currentData, string message, Exception inner) : base (message, inner)
		{
			this.CurrentData = currentData;
		}
	}
}
