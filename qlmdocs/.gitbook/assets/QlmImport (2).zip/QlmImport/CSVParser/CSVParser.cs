﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace CSVParser
{
	/// <summary>
	/// Represents a fairly lightweight CSV file/stream parser. Since this is an abstract class, 
	/// your deriving class should set the config properties before you begin to parse a file.
	/// </summary>
	public abstract class CSVParser
	{
		#region fields

		private bool      hasHeaderRow          = true;
		private string    exactDateTimeFormat   = "M/d/yyyy";
		private bool      removeCurrencySymbols = true;
		private bool      throwFindExceptions   = false;
		private bool      isMalformed           = false;
		private List<int> invalidLines          = new List<int>();
		private string    currencySymbol        = string.Empty;

        StringBuilder sbResult = new StringBuilder();
        int importCount = 0;

        

        #endregion fields

        #region config properties

        /// <summary>
        /// Get/set a flag indicating whether the first row is a header row
        /// </summary>
        public bool HasHeaderRow 
		{
			get { return this.hasHeaderRow; }
			set { this.hasHeaderRow = value; }
		}

		/// <summary>
		/// Get/set the expected datetime format
		/// </summary>
		public string ExactDateTimeFormat
		{
			get { return this.exactDateTimeFormat; }
			set { this.exactDateTimeFormat = value; }
		}

		/// <summary>
		/// Get/set a flag indicating whether or not to remove currency symbols
		/// </summary>
		public bool RemoveCurrencySymbols
		{
			get { return this.removeCurrencySymbols; }
			set { value = this.removeCurrencySymbols; }
		}

		/// <summary>
		/// Get/set flag that indicates whether theis class throws exceptions when a field does 
		/// not parse to the desired object type.
		/// </summary>
		public bool ThrowFindExceptions
		{
			get { return this.throwFindExceptions; }
			set { this.throwFindExceptions = value; }
		}

		/// <summary>
		/// Get/set the currency symbol to look for when stripping currency symbols. If this value 
		/// is null/empty, the code will use the culture-specific currency symbol as determined by 
		/// the operating system.
		/// </summary>
		public string CurrencySymbol 
		{
			get { return this.currencySymbol; }
			set { this.currencySymbol = value; }
		}

        public StringBuilder SbResult
        {
            get
            {
                return sbResult;
            }

            set
            {
                sbResult = value;
            }
        }

        public int ImportCount
        {
            get
            {
                return importCount;
            }

            set
            {
                importCount = value;
            }
        }

        #endregion config properties

        #region internal properties

        // these properties are set by this class and/or it's derving classes

        /// <summary>
        /// Get/set the data stream 
        /// </summary>
        public StreamReader DataStream { get; set; }

		/// <summary>
		/// Contains the column header names and their associated index within the parsed header 
		/// line. If the file/stream does not have a header row, the keys are merely string 
		/// representations of the numeric index value.
		/// </summary>
 		protected Dictionary<string, int> Columns { get; set; }

		/// <summary>
		/// Get/set the array of values found in the current line
		/// </summary>
		protected string[] CurrentData { get; set; }

		/// <summary>
		/// Get/set the current line being parsed. 
		/// </summary>
		/// <remarks>We do this so we can condct forensic operations on a line that generated an error.</remarks>
		protected string CurrentLine { get; set; }

		/// <summary>
		/// Get/set a flag indicating whether the current line is malformed;
		/// </summary>
		protected bool IsMalformed 
		{
			get { return this.isMalformed; }
			set { this.isMalformed = value; }
		}

		/// <summary>
		/// Get/set the list of line indexes for lines that were invalid even after an attempt to auto correct
		/// </summary>
		public List<int> InvalidLines
		{
			get { return this.invalidLines; }
			set { this.invalidLines = value; }
		}

		/// <summary>
		/// Get count of total lines processed (good, bad, or otherwise). This value does not count blank lines or the header row.
		/// </summary>
		public int TotalLinesProcessed { get; set; }

		#endregion internal properties


		#region constructor/destructor

		/// <summary>
		/// Constructor - Initializes this instance of the CSVParser object.
		/// </summary>
		/// <param name="hasHeaderRow">Indicates whether the file has a header row (default=true)</param>
		/// <param name="exactDateTimeFormat">The expected DateTime format por the DateTime.ParseExact method - default = "M/d/yyyy"</param>
		public CSVParser()
		{
			this.Columns             = new Dictionary<string, int>();
			this.CurrentLine         = string.Empty;
			this.CurrentData         = null;
			this.DataStream          = null;
			this.TotalLinesProcessed = 0;
		}

		/// <summary>
		/// Cleanup
		/// </summary>
		~CSVParser()
		{
			this.DisposeStream();
		}

		#endregion constructor/destructor


		#region public methods (and their private helpers)

		/// <summary>
		/// Opens the specified filename, and sets the DataStream property
		/// </summary>
		/// <param name="filename">The name of the file to open and parse.</param>
		/// <exception cref="">Thrown if there was a problem (file or folder doesn't exist, etc)</exception>
		private void OpenFile(string filename)
		{
			try
			{
				this.DisposeStream();
                this.DataStream = new StreamReader(filename, Encoding.UTF8);
			}
			catch (Exception ex)
			{
				throw new Exception("Error opening file.", ex);
			}
		}

		/// <summary>
		/// Opens the specified stream and sets the DataStream property
		/// </summary>
		/// <param name="stream">The stream to open and parse</param>
		/// <exception cref="">Thrown if the stream is null or somehow invalid.)</exception>
		private void OpenStream(Stream stream)
		{
			try
			{
				this.DisposeStream();
				this.DataStream = new StreamReader(stream); 
			}
			catch (Exception ex)
			{
				throw new Exception("Error opening stream.", ex);
			}
		}

		/// <summary>
		/// Parses the specified file
		/// </summary>
		/// <param name="filename">The name of the file to be parsed</param>
		public virtual void Parse(string filename)
		{
			if (string.IsNullOrEmpty(filename))
			{
				throw new ArgumentNullException("filename");
			}

			this.OpenFile(filename);
			this.Parse();

            // Fix 2017-11-09
            this.DisposeStream();
		}

		/// <summary>
		/// Parses the specific stream
		/// </summary>
		/// <param name="filename">The (file) stream to be parsed</param>
		public virtual void Parse(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}
			this.OpenStream(stream);
			this.Parse();

            // Fix 2017-11-09
            this.DisposeStream();
        }

		#endregion public methods (and their private helpers)


		#region parsing methods (protected)

		/// <summary>
		/// Parses the actual data from the file/stream, and calls the abstract ProcessFields 
		/// method for every line of data.
		/// </summary>
		protected virtual void Parse()
		{

			if (this.DataStream == null)
			{
				throw new InvalidOperationException("DataStream object is null.");
			}

			this.Columns.Clear();
			this.InvalidLines.Clear();
	
			// sheet is not going to be null by the time we get here
			string line = string.Empty;
			int lineCounter = -1;

			while ((line = this.DataStream.ReadLine ()) != null)
			{
				lineCounter++;
				// if the column dictionary is null or empty, set the columns
				if (this.Columns == null || this.Columns.Count == 0)
				{
					// populate the Columns dictionary
					this.MakeColumnDictionary(line);

					// If we have a header row, move to the next line in the file. If we 
					// don't, since  we used a data line to establish columns, we still need 
					// to parse the line as data, so we don't "continue".
					if (this.HasHeaderRow)
					{
						continue;
					}
				}

				// ignore blank lines
				if (string.IsNullOrEmpty(line))
				{
					continue;
				}

				// read the fields in the string.
				this.CurrentData = this.ReadFields(line);

				// if the string is malformed, add its index to the InvalidLines list
				if (this.IsMalformed)
				{
					this.InvalidLines.Add(lineCounter);
				}

				this.TotalLinesProcessed++;

				// strip double double quotes, currency symbol and quotes around quoted strings.
				this.FinalCleanup();

				// call the qbstract method so the deriving class can handle the parsed fields.
				this.ProcessFields(this.IsMalformed);

			} // while ((line = this.DataStream.ReadLine()) != null)

			// call the abstract method so the deriving class can react to the parsing being completed.
			this.Finished();
		}

		/// <summary>
		/// Creates a dictionary of column names and their numeric indexes in the csv file. 
		/// </summary>
		/// <param name="line">Text that represents the first line from the CSV file</param>
		protected virtual void MakeColumnDictionary(string line)
		{
			// we do this at the top of the Parse() method, but you can't be too safe.
			this.Columns.Clear();

			// parse the string
			try
			{
				string[] parts = this.ReadFields(line);
				if (!this.IsMalformed)
				{
					for (int i = 0; i < parts.Length; i++)
					{
						if (this.HasHeaderRow)
						{
							// excel surrounds headers with square brackets, so we're going to remove them 
							// to make finding the header names a little more efficient. We temporarily 
							// disable autocorrect because there's no current column count, resulting in 
							// the inability to properly determine how many fields there should be.
							this.Columns.Add(parts[i].Replace("[","").Replace("]",""), i);
							// return auto correct to it's prior state
						}
						else
						{
							// since we don't have a header row, we use the field index as the header name 
							// so you can stiull search for column "1", "2", etc.
							this.Columns.Add(i.ToString(), i);
						}
					}
				}
				else
				{
					throw new Exception("Header row (or first row) appears to be malformed.");
				}
			}
			catch (Exception ex)
			{
				throw new Exception("Exception encountered while parsing the header line", ex);
			}
		}

		/// <summary>
		/// Parses a string that represents one row of a CSV file (ostensibly generated by Excel), 
		/// and returns an array of strings that represents each comma-delimited field in that 
		/// string. 
		/// </summary>
		/// <param name="text">The comma-delimited string to be parsed</param>
		/// <returns>Array of strings found in the specified text</returns>
		protected virtual string[] ReadFields(string text, bool removeQuotes = true)
		{
			//assume we have a proper line of text
			this.IsMalformed = false;

			// split the string on commas (because this is a CSV file, after all)
			string[] parts = text.Trim().Split(',');

			// create a container for our results
			List<string> newParts = new List<string>();

			// set some initial values
			bool inQuotes = false;
			string currentPart = string.Empty;

			// iterate the parts array
			for (int i = 0; i < parts.Length; i++)
			{
				// get the part at the current index
				string part = parts[i];

				// if we're in a quoted string and the current part starts with a single double 
				// quote AND currentPart isn't empty, assume the currentPart is complete, add it to 
				// the newParts list, and reset for the new part
				if (inQuotes && part.StartsWithSingleDoubleQuote() == true && !string.IsNullOrEmpty(currentPart))
				{
					currentPart = string.Concat(currentPart, "\"");
					newParts.Add(currentPart);
					currentPart = string.Empty;
					inQuotes = false;
				}

				// see if we're in a quoted string
				inQuotes = (inQuotes || (!inQuotes && part.StartsWithSingleDoubleQuote() == true));

				// if so, add the part to the current currentPart
				if (inQuotes)
				{
					currentPart = (string.IsNullOrEmpty(currentPart)) ? part : string.Format("{0},{1}", currentPart, part);
				}
				// otherwise, simply set the currentPart to the part
				else
				{
					currentPart = part;
				}

				// see if we're still in a quoted string
				inQuotes = (inQuotes && currentPart.EndsWithSingleDoubleQuote() == false);
				// if not
				if (!inQuotes)
				{
					// remove the quote characters
					currentPart = (removeQuotes) ? currentPart.Trim('\"') : currentPart;
					// put the currentPart into our container
					newParts.Add(currentPart);
					// reset the currentPart
					currentPart = string.Empty;
				}
			}
			this.IsMalformed = (inQuotes || (this.Columns.Count > 0 && newParts.Count != this.Columns.Count));

			return newParts.ToArray();
		}

		/// <summary>
		/// Removes the escaping quotes from the ends of the field, and the specified currency symbol (if the field starts or ends with that symbol).
		/// </summary>
		protected virtual void FinalCleanup()
		{
			string currencySymbol = (string.IsNullOrEmpty(this.CurrencySymbol)) ?  CultureInfo.CurrentCulture.NumberFormat.CurrencySymbol : this.CurrencySymbol;
			if (this.CurrentData != null && this.CurrentData.Length > 0)
			{
				for (int i = 0; i < this.CurrentData.Length; i++)
				{
					this.CurrentData[i] = this.CurrentData[i].Trim().Replace("\"\"", "\"");
					if (this.RemoveCurrencySymbols && 
						(this.CurrentData[i].StartsWith(currencySymbol) || 
						 this.CurrentData[i].EndsWith(currencySymbol)))
					{
						this.CurrentData[i] = this.CurrentData[i].Replace(currencySymbol, "").Replace(",", "");
					}
				}
			}
		}

		#endregion parsing methods (protected)


		#region field retrieval methods

		/// <summary>
		/// Finds the column index for the named column (uses a SQL "IsLike" for comparison, so you 
		/// can use SQL wildcard characters when searching for columns).
		/// </summary>
		/// <param name="columns"></param>
		/// <param name="name"></param>
		/// <returns></returns>
		protected virtual int FindColumnIndex(string name)
		{
			int index = -1;
			foreach(string key in this.Columns.Keys)
			{
				if (key.IsLike(name))
				{
					index = this.Columns[key];
					break;
				}
			}
			return index;
		}

		/// <summary>
		/// Determines the actual name of the column. We need this because we need to name the 
		/// column if there's a FindValueException thrown.
		/// </summary>
		/// <param name="name">The approximate name of the column</param>
		/// <returns></returns>
		protected string FindActualColumnName(string name)
		{
			// since the column names are stored in a dictionary, we can't really rely on the 
			// dictionary elements to be in the order in which they were added, so we have to 
			// re-search by approximate name to get the whole name of the key
			string result = string.Empty;
			foreach(string key in this.Columns.Keys)
			{
				if (key.IsLike(name))
				{
					result = key;
					break;
				}
			}
			return result;
		}

		private bool ValidIndex(int index)
		{
			return (index < this.CurrentData.Length && index >= 0);
		}

		// These methods don't really need to throw an exception if the data isn't of the expected 
		// type because the default value is used to indicated a problem. However, if you really 
		// want exceptions thrown, set the ThrowFindExceptions property to true

		/// <summary>
		/// Finds the string value of the named column in the specified data string
		/// </summary>
		/// <param name="columns"></param>
		/// <param name="data"></param>
		/// <param name="name"></param>
		/// <param name="defaultValue"></param>
		/// <returns></returns>
		protected virtual string FindValue(string name, string defaultValue)
		{
			string value = defaultValue;
			int index = this.FindColumnIndex(name);
			if (this.ValidIndex(index))
			{
				//since we're just finding a string, there's no real way this method can generate an exception
				string str = this.CurrentData[index].Trim();
				value = (string.IsNullOrEmpty(str)) ? string.Empty : str;
			}
			return value;
		}

		/// <summary>
		/// Finds the integer value of the named column in the specified data string
		/// </summary>
		/// <param name="name"></param>
		/// <param name="defaultValue"></param>
		/// <returns></returns>
		protected virtual int FindValue(string name, int defaultValue)
		{
			int value = defaultValue;
			int index = this.FindColumnIndex(name);
			if (this.ValidIndex(index))
			{
				// remove any commas that might exist
				string str = this.CurrentData[index].Replace(",","").Trim();
				if (string.IsNullOrEmpty(str))
				{
					value = 0;
				}
				else
				{
					if (!int.TryParse(str, out value))
					{
						value = defaultValue;
					}
					else if (this.ThrowFindExceptions)
					{
						throw new FindValueException(this.CurrentLine, string.Format("'Find' error at column [{0}]", this.FindActualColumnName(name)));
					}
				}
			}
			return value;
		}

		/// <summary>
		/// Finds the double value of the named column in the specified data string
		/// </summary>
		/// <param name="name"></param>
		/// <param name="defaultValue"></param>
		/// <returns></returns>
		protected virtual double FindValue(string name, double defaultValue)
		{
			double value = defaultValue;
			string str = string.Empty;
			int index = this.FindColumnIndex(name);
			if (this.ValidIndex(index))
			{
				// remove any commas that might exist so we can use TryParse to verify that the 
				// value is indeed a double (or double-compatible)
				str = this.CurrentData[index].Replace(",","").Trim();
				if (string.IsNullOrEmpty(str))
				{
					value = 0d;
				}
				else
				{
					if (!double.TryParse(str, out value))
					{
						value = defaultValue;
					}
					else if (this.ThrowFindExceptions)
					{
						throw new FindValueException(this.CurrentLine, string.Format("'Find' error at column [{0}]", this.FindActualColumnName(name)));
					}
				}
			}
			return value;
		}

		/// <summary>
		/// Finds the DateTime value of the named column in the specified data string
		/// </summary>
		/// <param name="name"></param>
		/// <param name="defaultValue"></param>
		/// <returns></returns>
		protected virtual DateTime FindValue(string name, DateTime defaultValue)
		{
			DateTime value = defaultValue;
			int index = this.FindColumnIndex(name);
			if (this.ValidIndex(index))
			{
				string str = this.CurrentData[index].Trim();
				if (string.IsNullOrEmpty(str))
				{
					value = new DateTime(0);
				}
				else
				{
					if (!DateTime.TryParseExact(str, this.ExactDateTimeFormat, new CultureInfo("en-US"), DateTimeStyles.None, out value))
					{
						value = defaultValue;
					}
					else if (this.ThrowFindExceptions)
					{
						throw new FindValueException(this.CurrentLine, string.Format("'Find' error at column [{0}]", this.FindActualColumnName(name)));
					}
				}
			}
			return value;
		}

		#endregion field retrieval methods


		#region abstract methods

		/// <summary>
		/// Override this method to implement your own app-specific parsing;
		/// </summary>
		/// <param name="data"></param>
		protected abstract void ProcessFields(bool isMalformed);

		/// <summary>
		/// Called when the Parse() method is finished.
		/// </summary>
		protected abstract void Finished();

		#endregion abstract methods


		#region other helper methods

		private void DisposeStream()
		{
			if (this.DataStream != null)
			{
				this.DataStream.Close();
				this.DataStream.Dispose();
				this.DataStream = null;
			}
		}

		#endregion other helper methods

	}
}
