﻿using System;

namespace CSVParser
{
	// Usage: 
	//		CSVFileParser parser = new CSVFileParser();
	//		parser.Parse(@"pathto\myfile.csv");
	// (accepts either stream or filename)

	public class CSVFileParser : CSVParser
	{
		public CSVFileParser() : base()
		{
#if __Z__
			this.Hints.Add(new CSVHint(){ ColumnIndex=0, ColumnName = "Col1", DataType=CSVHintType.Int });
			this.Hints.Add(new CSVHint(){ ColumnIndex=1, ColumnName = "Col2", DataType=CSVHintType.String });
			this.Hints.Add(new CSVHint(){ ColumnIndex=2, ColumnName = "Col3", DataType=CSVHintType.QuotedString });
			this.Hints.Add(new CSVHint(){ ColumnIndex=3, ColumnName = "Col4", DataType=CSVHintType.String });
			this.Hints.Add(new CSVHint(){ ColumnIndex=4, ColumnName = "Col5", DataType=CSVHintType.QuotedString });
			this.Hints.Add(new CSVHint(){ ColumnIndex=5, ColumnName = "Col6", DataType=CSVHintType.QuotedString });
#endif
		}

		/// <summary>
		/// Parses the CurrentData property. The CurrentData property contains the parsed 
		/// comma-delimited line from the stream/file, and this method is called after each line is 
		/// parsed.
		/// </summary>
		protected override void ProcessFields(bool isMalformed)
		{
			if (this.CurrentData != null && !isMalformed)
			{
			//	// TO-DO: Your stuff
			//	try
			//	{
			//		int      col1 = this.FindValue("col1", -1);
			//		string   col2 = this.FindValue("col2", "ERROR");
			//		string   col3 = this.FindValue("col3", "ERROR");
			//		double   col4 = this.FindValue("col4", -1d);
			//		DateTime col5 = this.FindValue("col5", new DateTime(0));
			//	}
			//	catch (FindValueException fvex)
			//	{
			//		// this just gets rid of the compiler "declared but never used" warning.
			//		if (fvex != null) {}

			//		//TO-DO: react to an exception thrown because the value found could not be cast 
			//		// to the expected type.
			//	}
			}
		}

		protected override void Finished()
		{
			//TO-DO:	Celebration that could include dancing naked around a fire, singing songs 
			//			of a successful parsing event.

			// At this point you can examine the properties that show valid, invalid, and corrected 
			// line counts, as well as total lines processed (excluding the header row and blank 
			// lines).

		}

	}
}
