﻿using System;

using System.Collections.Generic;

using System.Text;

using System.Threading.Tasks;

using QlmLicenseLib;
using System.IO;

namespace QlmImport

{

    public class QlmUserGroupsParser

    {

        QlmLicense license1 = null;

        public QlmUserGroupsParser(QlmLicense license) : base()
        {
            license1 = license;
        }

        public string Parse(string fileName)
        {
            string response = string.Empty;

            DateTime lastUpdateDate = DateTime.Now;

            string content = File.ReadAllText(fileName, Encoding.UTF8);

            license1.UploadAffiliates(string.Empty, content, lastUpdateDate, out response);

            return response;

        }

    }

}
